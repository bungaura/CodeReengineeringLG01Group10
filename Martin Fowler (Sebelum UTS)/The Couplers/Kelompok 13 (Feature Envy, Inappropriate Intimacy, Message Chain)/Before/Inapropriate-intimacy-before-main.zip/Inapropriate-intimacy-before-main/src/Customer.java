public class Customer {
        public String name;
        public String address;
    
        public Customer(String name, String address) {
            this.name = name;
            this.address = address;
        }
    
}
